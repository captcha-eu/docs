DELETE FROM `#__rsform_component_types` WHERE `ComponentTypeId` IN (9999);

INSERT IGNORE INTO `#__rsform_component_types` (`ComponentTypeId`, `ComponentTypeName`, `CanBeDuplicated`) VALUES
(9999, 'captchaeu', 0);

INSERT IGNORE INTO `#__rsform_config` (`SettingName`, `SettingValue`) VALUES
('captchaeu.site.key', ''),
('captchaeu.secret.key', '');

DELETE FROM `#__rsform_component_type_fields` WHERE ComponentTypeId = 9999;

INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Properties`, `Ordering`) VALUES
(9999, 'NAME', 'textbox', '', '', 0),
(9999, 'CAPTION', 'textbox', '', '', 1),
(9999, 'ADDITIONALATTRIBUTES', 'textarea', '', '', 2),
(9999, 'DESCRIPTION', 'textarea', '', '', 3),
(9999, 'VALIDATIONMESSAGE', 'textarea', 'INVALIDINPUT', '', 4),
(9999, 'COMPONENTTYPE', 'hidden', '9999', '', 8);