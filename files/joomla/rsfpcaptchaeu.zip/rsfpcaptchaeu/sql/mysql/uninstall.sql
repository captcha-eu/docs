DELETE FROM #__rsform_component_types WHERE ComponentTypeId = 9999;
DELETE FROM #__rsform_component_type_fields WHERE ComponentTypeId = 9999;

DELETE FROM #__rsform_config WHERE SettingName = 'captchaeu.site.key';
DELETE FROM #__rsform_config WHERE SettingName = 'captchaeu.secret.key';
