var RSFormProCaptchaEU = {
	forms: {},
	loaders: [],
	onLoad: function() {
		window.setTimeout(function(){
			for (var i = 0; i < RSFormProCaptchaEU.loaders.length; i++) {
				var func = RSFormProCaptchaEU.loaders[i];
				if (typeof func === 'function') {
					try {
						func();
					} catch (err) {
						if (console && typeof console.log === 'function') {
							console.log(err);
						}
					}
				}
			}
		}, 500);
	}
};

RSFormProUtils.addEvent(window, 'load', RSFormProCaptchaEU.onLoad);

function CaptchaEUSubmit(x) {
	var form = RSFormPro.getForm(x);
	var hiddenField = document.createElement("input");
    hiddenField.type = "hidden";
    hiddenField.className = "captcha_at_hidden_field";
    hiddenField.name = "captcha_at_solution";
    form.appendChild(hiddenField);
	var elements = form.getElementsByClassName('rsform-submit-button');
	elements[0].disabled =true

	KROT.getSolution()
	    .then((sol) => {
			hiddenField.value = JSON.stringify(sol);
			RSFormPro.submitForm(form)
			elements[0].disabled =false
		})
}
