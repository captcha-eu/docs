<?php
/**
* @package RSForm! Pro
* @copyright (c) 2022 www.captcha.eu
* @copyright (C) 2007-2019 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

defined('_JEXEC') or die('Restricted access');

require_once JPATH_ADMINISTRATOR.'/components/com_rsform/helpers/field.php';

class RSFormProFieldCaptchaeu extends RSFormProField
{
	// backend preview
	public function getPreviewInput()
	{

		
		return "Captcha.eu";
	}
	
	// functions used for rendering in front view
	public function getFormInput() {

		$formId			= $this->formId;
		$componentId	= $this->componentId;

		// If no site key has been setup, just show a warning
		$siteKey = RSFormProHelper::getConfig('captchaeu.site.key');
		if (!$siteKey)
		{
			return '<div>'.JText::_('RSFP_CAPTCHAEU_NO_SITE_KEY').'</div>';
		}

		// Need to load scripts one-time.
		$this->loadScripts();

		$size	= strtolower($this->getProperty('SIZE', 'normal'));
		$params = array(
			'sitekey' => $siteKey,
		);
		$onsubmit = '';

		
			$params['badge'] = strtolower($this->getProperty('BADGE', 'inline'));
			$params['callback'] = 'RSFormProInvisibleCallback' . $formId;

			$form = RSFormProHelper::getForm($formId);

			// Need to trigger captcha-eu
				$onsubmit = "RSFormProUtils.addEvent(RSFormPro.getForm({$formId}), 'submit', function(evt){ evt.preventDefault(); 
	RSFormPro.submitForm(RSFormPro.getForm({$formId})); });";
			

			$onsubmit .= "RSFormPro.addFormEvent({$formId}, function(){ CaptchaEUSubmit({$formId}) });";
		
		// JSON-Encode parameters
		$params = json_encode($params);

		$script = '';



		// Create the script
		$script .= <<<EOS
		var CaptchaEUSettings = {
			publicSecret: "{$siteKey}"
	};
RSFormProCaptchaEU.loaders.push(function(){
	if (typeof RSFormProCaptchaEU.forms[{$formId}] === 'undefined') {
		
		{$onsubmit}
	}
});
EOS;
		RSFormProAssets::addScriptDeclaration($script);

		$out = 'xxx';

		

		// Clear the token on page refresh
		JFactory::getSession()->clear('com_rsform.captchaeuToken'.$formId);

		return "";
	}
	public function validate($solution, $endpoint, $privateSecret)
    {
        $url = $endpoint;
        $restKey = $privateSecret;
        $url = $url . '/validate';

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $solution);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Rest-Key: ' . $restKey));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);

        $resultObject = json_decode($result);
        if ($resultObject->success) {
            return true;
        }
        return false;
    }
	public function processValidation($validationType = 'form', $submissionId = 0)
	{
		// Skip directory editing since it makes no sense
		if ($validationType == 'directory')
		{
			return true;
		}

		$formId 	 = $this->formId;
		$form       = RSFormProHelper::getForm($formId);
		$logged		= $form->RemoveCaptchaLogged ? JFactory::getUser()->id : false;
		$secretKey 	= RSFormProHelper::getConfig('captchaeu.secret.key');

		// validation:
		// if there's no session token
		// validate based on challenge & response codes
		// if valid, set the session token

		// session token gets cleared after form processes
		// session token gets cleared on page refresh as well

		if (!$secretKey)
		{
			JFactory::getApplication()->enqueueMessage(JText::_('RSFP_CAPTCHAEU_MISSING_INPUT_SECRET'), 'error');
			return false;
		}

		if (!$logged)
		{
			$input 	  = JFactory::getApplication()->input;
			$session  = JFactory::getSession();
			$response = $input->post->get('captcha_at_solution', '', 'raw');
			$ip		  = \Joomla\Utilities\IpHelper::getIp();
			$task	  = strtolower($input->get('task'));
			$option	  = strtolower($input->get('option'));
			$isAjax	  = $option == 'com_rsform' && $task == 'ajaxvalidate';
			$isPage   = $input->getInt('page');

			// Already validated, move on
			if ($session->get('com_rsform.captchaeuToken'.$formId))
			{
				return true;
			}

			// Ajax requests don't validate captcha on page change
			if ($isAjax && $isPage)
			{
				return true;
			}

			$valid = $this->validate($response, "https://www.captcha.eu",$secretKey);
			if(!$valid) {
				JFactory::getApplication()->enqueueMessage(JText::_('RSFP_CAPTCHAEU_FAILED'), 'error');
			}
			return $valid;
		}

		return true;
	}

	protected function loadScripts()
	{
		static $loaded;

		if (!$loaded)
		{
			$loaded = true;
		
			
				RSFormProAssets::addCustomTag('<script src="https://www.captcha.eu/sdk.js" async defer></script>');
    			RSFormProAssets::addScript(JHtml::_('script', 'plg_system_rsfpcaptchaeu/captcha.js', array('pathOnly' => true, 'relative' => true)));
		}
	}
}