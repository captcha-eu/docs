<?php

    /**
     * @copyright   captcha.eu
     * @license     GNU General Public License version 2 or later
     */

    use Joomla\CMS\Language\Text;

    // phpcs:disable PSR1.Files.SideEffects
    \defined('_JEXEC') or die;
    // phpcs:enable PSR1.Files.SideEffects

    class JFormRulePublickey
    {
        public function test($element, $value, $group = null, $input = null, $form = null)
        {
            // api host
            $apiHost = 'https://www.captcha.eu';

            // get submitted values
            $restKey = $input->get('params')->restKey;
            $publicKey = $input->get('params')->publicKey;

            // verify both keys are set
            if(empty($restKey) || empty($publicKey)) {
                // empty keys => invalid
                return false;
            }

            // call API with given restKey & check if publicKey matches
            $ch = curl_init($apiHost . '/api/personal');
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Rest-Key: ' . $restKey,
                'Content-Type: application/json',
                'User-Agent: Captcha'
            ));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_VERBOSE, true);
            $result = curl_exec($ch);

            // check if curl errors occured
            if (curl_errno($ch)) {
                $element->addAttribute('message', Text::_('PLG_CAPTCHA_EU_MSG_ERR_CONNECTION_FAILED'));
                curl_close($ch);
                return false;
            }

            curl_close($ch);
            $resultObject = json_decode($result);

            // check if id is set
            if(!isset($resultObject->id)) {
                // id not set => invalid
                $element->addAttribute('message', Text::_('PLG_CAPTCHA_EU_MSG_ERR_INVALID_RESPONSE'));
                return false;
            }

            // check if public key matches
            if($publicKey != $resultObject->publicSecret) {
                // publicKey not matching account => invalid
                $element->addAttribute('message', Text::_('PLG_CAPTCHA_EU_MSG_ERR_KEY_MISMATCH'));
                return false;
            }

            // valid
            return true;
        }
    }

?>