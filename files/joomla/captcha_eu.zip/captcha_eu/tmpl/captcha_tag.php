<script>
    // Only Run Once
    if (!CPTDOMReady) {
        var CPTDOMReady = function(callback) {
            document.readyState === "interactive" || document.readyState === "complete" ?
                callback() :
                document.addEventListener("DOMContentLoaded", callback);
        };

        CPTDOMReady(() => {
            KROT.setup("<?php echo $pubKey ?>");
            window.JCaptchaEU.forEach(function(el) {
                var htmlEl = document.querySelector("#" + el);
                var f = htmlEl.closest("form");
                if (f) {
                    KROT.interceptForm(f)
                }
            });
        })


    }
    if (!window.JCaptchaEU) {
        window.JCaptchaEU = []
    }
    // Register Field 
    window.JCaptchaEU.push("<?php echo $id ?>");
</script>
<input type="hidden" id="<?php echo $id ?>">