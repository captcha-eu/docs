<?php

/**
 * @package     Joomla.Plugin
 * @subpackage  Captcha
 *
 * @copyright   captcha.eu
 * @license     MIT

 * @phpcs:disable Squiz.Classes.ValidClassName.NotCamelCaps

 * @phpcs:disable PSR1.Classes.ClassDeclaration.MissingNamespace
 */

use Joomla\CMS\Captcha\Google\HttpBridgePostRequestMethod;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Utilities\IpHelper;
use Joomla\CMS\Plugin\PluginHelper;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * Invisible CaptchaEU Plugin.
 *
 * @since  3.9.0
 */
class PlgCaptchacaptcha_eu extends CMSPlugin
{
    /**
     * Load the language file on instantiation.
     *
     * @var    boolean
     * @since  3.9.0
     */
    protected $autoloadLanguage = true;

    /**
     * Application object.
     *
     * @var    \Joomla\CMS\Application\CMSApplication
     * @since  4.0.0
     */
    protected $app;

    /**
     * Reports the privacy related capabilities for this plugin to site administrators.
     *
     * @return  array
     *
     * @since   3.9.0
     */
    public function onPrivacyCollectAdminCapabilities()
    {
        $this->loadLanguage();

        return [
            Text::_('PLG_CAPTCHA_CAPTCHA_EU') => [
                Text::_('PLG_CAPTCHA_TXT'),
            ],
        ];
    }

    /**
     * Initialise the captcha
     *
     * @param   string  $id  The id of the field.
     *
     * @return  boolean True on success, false otherwise
     *
     * @since   3.9.0
     * @throws  \RuntimeException
     */
    public function onInit($id = 'dynamic_captcha_eu1')
    {
        $pubKey = $this->params->get('publicKey', '');
        $restKey = $this->params->get('restKey', '');

        if ($pubKey === '') {
            throw new \RuntimeException(Text::_('PLG_CAPTCHA_EU_MISSING_PUBKEY'));
        }
        if ($restKey === '') {
            throw new \RuntimeException(Text::_('PLG_CAPTCHA_EU_MISSING_RESTKEY'));
        }

        $sdkSrc = 'https://www.captcha.eu/sdk.js';

        // Load assets, the callback should be first
        $this->app->getDocument()->getWebAssetManager()
            ->registerAndUseScript('plg_captcha_eu_sdk_src', $sdkSrc, [], ['defer' => true]);
            

        return true;
    }

    public function checkSolution($solution) {
        $restKey = $this->params->get('restKey', '');
        $ch = curl_init("https://www.captcha.eu/validate");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $solution);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Rest-Key: ' . $restKey));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
  
        $resultObject = json_decode($result);
        if ($resultObject->success) {
          return true;
        } else {
          return false;
        }
      }
    /**
     * Gets the challenge HTML
     *
     * @param   string  $name   The name of the field. Not Used.
     * @param   string  $id     The id of the field.
     * @param   string  $class  The class of the field.
     *
     * @return  string  The HTML to be embedded in the form.
     *
     * @since  3.9.0
     */
    public function onDisplay($name = null, $id = 'dynamic_recaptcha_invisible_1', $class = '')
    {
        $pubKey = $this->params->get('publicKey', '');

        ob_start();
		include PluginHelper::getLayoutPath($this->_type, $this->_name, 'captcha_tag');
		return ob_get_clean();

    }

    /**
     * Calls an HTTP POST function to verify if the user's guess was correct
     *
     * @param   string  $code  Answer provided by user. Not needed for the Recaptcha implementation
     *
     * @return  boolean  True if the answer is correct, false otherwise
     *
     * @since   3.9.0
     * @throws  \RuntimeException
     */
    public function onCheckAnswer($code = null)
    {
        $input      = Factory::getApplication()->input;
        $restKey = $this->params->get('restKey');
        
        $response  = $input->get('captcha_at_solution', '', 'string');

        // Check for Private Key
        if (empty($restKey)) {
            throw new \RuntimeException(Text::_('PLG_CAPTCHA_EU_MISSING_RESTKEY'));
        }

        
        return $this->getResponse($restKey, $response);
    }

    /**
     * Method to react on the setup of a captcha field. Gives the possibility
     * to change the field and/or the XML element for the field.
     *
     * @param   \Joomla\CMS\Form\Field\CaptchaField  $field    Captcha field instance
     * @param   \SimpleXMLElement                    $element  XML form definition
     *
     * @return void
     *
     * @since 3.9.0
     */
    public function onSetupField(\Joomla\CMS\Form\Field\CaptchaField $field, \SimpleXMLElement $element)
    {
        // Hide the label for the captcha_field
        $element['hiddenLabel'] = 'true';
    }

    /**
     * Get the captcha response.
     *
     * @param   string  $privatekey  The private key for authentication.
     * @param   string  $remoteip    The remote IP of the visitor.
     * @param   string  $response    The response received from Google.
     *
     * @return  boolean  True if response is good | False if response is bad.
     *
     * @since   3.9.0
     * @throws  \RuntimeException
     */
    private function getResponse($privatekey,  $response)
    {
       $suc = $this->checkSolution($response);
       
        return $suc;
    }
}
